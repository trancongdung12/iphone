<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/home/payment.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Payment</title>
</head>
<body>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container" style="margin-top: 100px">
           <form class="form-payment" action="/payment" method="post">
            <?php echo csrf_field(); ?>
               <div class="left-form">
                <p class="header">THÔNG TIN THANH TOÁN</p>
                 <div class="form-item">
                        <label for="">Tên Người Nhận <span style="color: red">*</span></label>
                        <input name="name" type="text" required>
                 </div>
                 <div class="form-item">
                    <label for="">Địa chỉ  <span style="color: red">*</span></label>
                    <input name="address" type="text" required>
                </div>
                <div class="form-item">
                <label for="">Số điện thoại <span style="color: red">*</span></label>
                <input name="phone" type="text" required>
                </div>

                <div class="form-item">
                    <label for="">Ghi chú (tùy chọn)</label>
                    <textarea name="note" id="" cols="30" rows="3"></textarea>
                </div>

            </div>
            <div class="right-form">
                <p class="header">ĐƠN HÀNG CỦA BẠN</p>
                <div class="space-row">
                        <b>SẢN PHẨM</b> <b>TỔNG</b>
                </div>
                <hr>
                    <?php $total = 0; $i=0; ?>
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="space-row">
                        <span>
                        <input disabled  name="name_product" class="input-hide" value="<?php echo e($item->name); ?>" type="text">
                            <b style="color: red"> x
                            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($carts->id_product==$item->id): ?>
                                <?php echo e($qty = $carts->quantity); ?>

                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </b>
                        </span>
                        <b><?php echo e(number_format($qty*$item->price)); ?> đ</b>
                    </div>
                    <?php
                                $total += $qty*$item->price;
                    ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <hr>
                <div class="space-row">
                    <b>Tổng phụ</b> <b><?php echo e(number_format($total)); ?> đ</b>
               </div>
               <hr>
               <div class="space-row">
                <b>Giao hàng</b> <span>Giao hàng miễn phí</span>
                </div>
                <hr>
                <div class="space-row">
                <b>Tổng</b> <b><?php echo e(number_format($total)); ?>đ</b>
                </div>
                <hr>

                <div class="checkbox">
                    <input type="checkbox" name="payment" id="" checked><b>  Trả tiền khi nhận hàng</b>
                </div>
                <div class="checkbox">
                    <input type="checkbox" name="payment" id=""><b>  Thanh toán bằng thẻ</b>
                </div>
                <button class="btn-pay">Đặt hàng</button>
            </div>
           </form>
    </div>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH E:\Laravel\projectSell\resources\views/user/payment.blade.php ENDPATH**/ ?>