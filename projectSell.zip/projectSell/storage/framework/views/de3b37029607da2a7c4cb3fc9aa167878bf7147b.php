<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>
<style>
    ul.nav.navbar-nav {
     display: inline;
}
#row{
    width: 100% !important;
}
</style>
<body>
<div class="navbar navbar-inverse">

            <div class="row" id="row">



                    <div class="navbar-collapse collapse" id="mobile_menu" style="display: flex">
                        <div class="navbar-header">
                            <button class="navbar-toggle" data-target="#mobile_menu" data-toggle="collapse"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                            <a href="/home" class="navbar-brand">DUNGX-IPHONE</a>
                        </div>

                        <ul class="nav navbar-nav">
                            <li class="active"><a href="/home">Trang chủ</a></li>
                            <li><a href="#">Dịch vụ</a></li>
                             <li><a href="#">Liên hệ</a></li>
                            <li><a href="#">Về chúng tôi</a></li>
                        </ul>
                        <ul class="nav navbar-nav">
                            <li>
                                <form action="" class="navbar-form">
                                    <div class="form-group">
                                        <div class="input-group">
                                            <input type="search" name="search" id="" placeholder="Tìm kiếm..." class="form-control">
                                            <span class="input-group-addon"><span class="glyphicon glyphicon-search"></span></span>
                                        </div>
                                    </div>
                                </form>
                            </li>
                        </ul>

                        <ul class="nav navbar-nav navbar-right">
                            <?php if(Auth::user()): ?>
                            <li><a href="/cart">Giỏ hàng (<?php echo e(Session::get('countCart')); ?>) <i class="fas fa-shopping-cart"></i></a></li>
                            <li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span><?php echo e(Auth::user()->name); ?></a>
                            <ul class="dropdown-menu">
                                <li><a href="/home/logout">Đăng xuất</a></li>

                            </ul>
                            </li>
                            <?php else: ?>
                            <li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-log-in"></span> Đăng nhập / Đăng ký </a>
                                <ul class="dropdown-menu">
                                    <li><a href="/home/login">Đăng nhập</a></li>
                                    <li><a href="/home/register">Đăng ký</a></li>
                                </ul>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>

            </div>

    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH E:\Laravel\projectSell\resources\views/partials/header.blade.php ENDPATH**/ ?>