<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Show product</title>
</head>
<body>
    @include('partials/adminhead')
    <div class="page-container" style="margin-top: 15px">
    <div class="container" style="margin-top: 120px;background-color: white">
        <h1>Show product</h1>
        <hr>
        <table class="table">
            <thead class="thead-dark">
              <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Phone</th>
                <th ></th>
              </tr>
            </thead>
            <tbody>
                <?php $i=1; ?>
                @foreach ($product as $item)
              <tr>
                <th scope="row"><?php echo $i++; ?></th>
                <td>{{$item->name}}</td>
                <td>0</td>
                <td>
                    <form action="/users/{{$item->id}}" method="post">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger">Delete</button>
                    </form>
                </td>
              </tr>
              @endforeach
            </tbody>
        </table>
    </div>
    </div>



</body>
</html>
