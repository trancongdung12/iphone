<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Edit</title>
</head>
<body>

    @include('partials/adminhead')
    <div class="page-container" style="margin-top: 15px">
        <div class="container" style="margin-top: 120px;background-color: white">
            <h1>Cập nhật sản phẩm</h1>
            <hr>
        <form action="/product/{{$pro->id}}" method="post" enctype="multipart/form-data" style="padding: 0px 40px">
                @csrf
                @method('PATCH')
                <div class="form-group">
                  <label for="exampleInputEmail1">Name</label>
                <input type="text" style="width: 300px" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" value="{{$pro->name}}">

                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Price</label>
                  <input type="text" name="price" style="width: 300px" class="form-control" id="exampleInputPassword1" placeholder="Price" value="{{$pro->price}}">
                </div>
                <label for="inputGroupFile04">Image</label>
                <div class="input-group">

                    <div class="custom-file">
                      <input type="file" name="image"  class="custom-file-input" id="inputGroupFile04">
                      <label class="custom-file-label"  style="width: 300px" for="inputGroupFile04">Choose file</label>
                    </div>
                  </div>
                <button style="margin-top: 20px" type="submit" class="btn btn-primary">Update</button>
              </form>
        </div>
    </div>

</body>
</html>
