<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/home/details.css">
    <title>Details</title>
</head>
<body>
    @include('partials/header')
    <div class="container">
        <div class="container-form">
            <div class="container-left">
            <img src="/storage/{{$product->image}}" alt="" height="500px" width="500px">
            </div>
            <div  class="container-right">
                    <p>{{$product->name}}</p>
                    <hr>
                    <p>{{number_format($product->price)}} đ</p>
                    <div>
                        <div style="display: flex">
                            <form action="/details/cart/{{$product->id}}" method="post">
                            <input type="number" name="qty-cart" min="1" max="{{$product->quantity}}" value="1">
                                @csrf
                            <button class="btn btn-danger">Thêm vào giỏ hàng</button>
                             </form>
                        </div>
                    </div>
                    <div class="tableparameter">


                        <p>Thông số kỹ thuật</p>
                        <ul class="parameter">
                        <li><b>Màn hình:</b><span>{{$detail[0]}}</span></li>
                            <li><b>Hệ điều hành:</b><span>{{$detail[1]}}</span></li>
                            <li><b>Camera sau:</b><span>{{$detail[2]}}</span></li>
                            <li><b>Camera trước:</b><span>{{$detail[3]}}</span></li>
                            <li><b>CPU:</b><span>{{$detail[4]}}</span></li>
                            <li><b>RAM:</b><span>{{$detail[5]}}</span></li>
                            <li><b>Bộ nhớ trong:</b><span>{{$detail[6]}}</span></li>
                            <li><b>Thẻ SIM:</b><span>{{$detail[7]}}</span></li>
                            <li><b>Dung lượng pin:</b><span>{{$detail[8]}}</span></li>
                        </ul>
                   </div>
            </div>
        </div>
    </div>
    <div class="container" id="other">
        <p class="txt-other"> SẢN PHẨM TƯƠNG TỰ</p>
        <hr class="hr-commend">
        <div style="display: flex;margin-left: 50px">
            @foreach ($sameproduct as $item)
             <div class="item-new">
             <img src="/storage/{{$item->image}}" alt="" height="200px" width="200px">
             <p>{{$item->name}}</p>
             <p><b>{{number_format($item->price)}} đ</b></p>
             <button class="btn btn-danger">Thêm vào giỏ hàng</button>
             </div>
             @endforeach
        </div>

    </div>


    @include('partials/footer')
</body>
</html>
