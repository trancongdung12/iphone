<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/home/payment.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Payment</title>
</head>
<body>
    @include('partials.header')
    <div class="container" style="margin-top: 100px">
           <form class="form-payment" action="/payment" method="post">
            @csrf
               <div class="left-form">
                <p class="header">THÔNG TIN THANH TOÁN</p>
                 <div class="form-item">
                        <label for="">Tên Người Nhận <span style="color: red">*</span></label>
                        <input name="name" type="text" required>
                 </div>
                 <div class="form-item">
                    <label for="">Địa chỉ  <span style="color: red">*</span></label>
                    <input name="address" type="text" required>
                </div>
                <div class="form-item">
                <label for="">Số điện thoại <span style="color: red">*</span></label>
                <input name="phone" type="text" required>
                </div>

                <div class="form-item">
                    <label for="">Ghi chú (tùy chọn)</label>
                    <textarea name="note" id="" cols="30" rows="3"></textarea>
                </div>

            </div>
            <div class="right-form">
                <p class="header">ĐƠN HÀNG CỦA BẠN</p>
                <div class="space-row">
                        <b>SẢN PHẨM</b> <b>TỔNG</b>
                </div>
                <hr>
                    <?php $total = 0; $i=0; ?>
                    @foreach ($product as $pro)
                        @foreach ($pro as $item)
                    <div class="space-row">
                        <span>
                        <input disabled  name="name_product" class="input-hide" value="{{$item->name}}" type="text">
                            <b style="color: red"> x
                            @foreach ($cart as $carts)
                            @if($carts->id_product==$item->id)
                                {{$qty = $carts->quantity}}
                            @endif
                            @endforeach
                            </b>
                        </span>
                        <b>{{number_format($qty*$item->price)}} đ</b>
                    </div>
                    <?php
                                $total += $qty*$item->price;
                    ?>
                     @endforeach
                     @endforeach

                <hr>
                <div class="space-row">
                    <b>Tổng phụ</b> <b>{{number_format($total)}} đ</b>
               </div>
               <hr>
               <div class="space-row">
                <b>Giao hàng</b> <span>Giao hàng miễn phí</span>
                </div>
                <hr>
                <div class="space-row">
                <b>Tổng</b> <b>{{number_format($total)}}đ</b>
                </div>
                <hr>

                <div class="checkbox">
                    <input type="checkbox" name="payment" id="" checked><b>  Trả tiền khi nhận hàng</b>
                </div>
                <div class="checkbox">
                    <input type="checkbox" name="payment" id=""><b>  Thanh toán bằng thẻ</b>
                </div>
                <button class="btn-pay">Đặt hàng</button>
            </div>
           </form>
    </div>
    @include('partials.footer')
</body>
</html>
