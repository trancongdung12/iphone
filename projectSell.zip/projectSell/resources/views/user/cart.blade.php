<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.7/css/all.css">
    <link rel="stylesheet" href="../css/home/cart.css">
    <title>Cart</title>
</head>
<body>
        @include('partials.header')

        <div class="container">
                <p style="color: red">{{Request::get('message')}}</p>
                <div class="form" style="display: flex">

                    <div class="left-form">
                        <table class="table">
                            <thead>
                              <tr>
                                <th scope="col">Sản phẩm</th>
                                <th scope="col">Giá</th>
                                <th scope="col">Số lượng</th>
                                <th scope="col">Tổng</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php $total =0; ?>
                                @foreach ($product as $item)
                                @foreach ($item as $key)

                              <tr >
                                <td>

                                    <img src="/storage/{{$key->image}}" alt="Image" height="100px" width="100px">
                                    <b>{{$key->name}}</b>
                                </td>
                                <td class="td-cart">{{number_format($key->price)}}đ</td>
                                @foreach($cart as $carts)
                                 @if($key->id==$carts->id_product)
                                      <?php $number = $carts->quantity;
                                            $id_cart = $carts->id;
                                      ?>
                                 @endif
                                 @endforeach
                                <td class="td-cart">
                                    <form action="/cart/{{$id_cart}}" method="post">
                                        @method('PATCH')
                                        @csrf
                                    <input type="number" name="qty-cart" value="{{$number}}" min="1" max="{{$key->quantity}}">
                                    <button class="btn-update-cart">Cập nhật</button>
                                     </form>
                                </td>



                                <td  class="td-cart">{{number_format($number*$key->price)}} đ</td>
                                <td> <form action="/cart/{{$id_cart}}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button style="background:none;border:none" type="submit"><i class="fas fa-trash-alt"></i></button>
                                </form></td>

                              </tr>
                              <?php
                                   $total += $number*$key->price;
                              ?>
                              @endforeach
                              @endforeach
                            </tbody>
                        </table>
                        <div style="margin-left: 50px">
                            <form action="/home" method="get">
                            <button class="btn-countinue" type="submit"><i class="fas fa-long-arrow-alt-left"></i>TIẾP TỤC XEM SẢN PHẨM</button>
                            </form>

                        </div>
                    </div>
                    <div class="right-form" >
                        <table class="table">
                            <thead>
                              <tr>
                                <th scope="col">Tổng số lượng</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr >
                                <td id="col-space"><span>Tổng phụ </span><b>{{number_format($total)}} đ</b></td>
                              </tr>
                              <tr >
                                <td  id="col-space"><span>Giao hàng</span> <b>Giao hàng miễn phí</b></td>
                              </tr>
                              <thead>
                                <tr>
                                  <th  id="col-space" scope="col"><span>Tổng</span> <b>{{number_format($total)}} đ</b></th>
                                </tr>
                              </thead>
                              <tr>
                                    <td>
                                        <form action="/payment" method="get">
                                            @csrf
                                            <button class="btn-pay">TIẾN HÀNH THANH TOÁN</button>
                                        </form>
                                    </td>
                              </tr>
                              <thead>
                                <tr>
                                  <th scope="col"><i class="fas fa-tags"></i> Phiếu ưu đãi</th>
                                </tr>
                              </thead>
                              <tr>
                                  <td><input class="discount" type="text" placeholder="Mã ưu đãi"></td>
                              </tr>
                              <tr>
                                <td><button class="btn-primary">Áp Dụng</button></td>
                              </tr>

                            </tbody>
                        </table>
                    </div>
                </div>

        </div>
        @include('partials.footer')
</body>
</html>
