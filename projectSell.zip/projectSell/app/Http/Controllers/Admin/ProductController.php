<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class ProductController extends Controller
{
    function index(){
        return view('admin.product.addproduct');
    }
    function show(){
        $allproduct = DB::table('product')->get();
        return view('admin.product.showproduct',['product'=>$allproduct]);
    }
    function store(Request $request){
        $name = $request->input('name');
        $price = $request->input('price');
        $image = $request->file('image')->store('public');
        $category = $request->input('category');
        $quantity = $request->input('quantity');
        $detail = $request->input('screen').'//'.$request->input('system').'//'.$request->input('backcam').'//'.$request->input('frontcam')
        .'//'.$request->input('cpu').'//'.$request->input('ram').'//'.$request->input('store').'//'.$request->input('sim').'//'.$request->input('pin');
        echo $detail;
        DB::table('product')->insert(['name'=>$name,'price'=>$price,'image'=>$image,'quantity'=>$quantity,'category'=>$category,'detail'=>$detail]);
        return redirect('/product/show');
    }
    function destroy($id){
        DB::table('product')->where('id',$id)->delete();
        return redirect('/product/show');
    }
    function edit($id){
       $getProduct = DB::table('product')->find($id);
       return view('admin.product.editproduct',['pro'=>$getProduct]);
    }
    function update($id,Request $request){
        $name = $request->input('name');
        $price = $request->input('price');
        $image = $request->file('image')->store('public');
        DB::table('product')->where('id','=',$id)->update(['name'=>$name,'price'=>$price,'price'=>$price,'image'=>$image]);
        return redirect('/product/show');
    }

}
