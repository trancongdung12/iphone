<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    function show(){
        $alluser = DB::table('users')->where('role','user')->get();
        return view('admin.users.index',['product'=>$alluser]);
    }
    function destroy($id){
        DB::table('users')->where('id',$id)->delete();
        return redirect('/users/show');
    }
}
