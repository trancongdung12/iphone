<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
class PaymentController extends Controller
{
    function index(){
        $id_user = Auth::user()->id;
        $cart = DB::table('cart')->where('id_user',$id_user)->get();
        foreach ($cart as $item){
            $product[] = DB::table('product')->where('id',$item->id_product)->get(['id','name','price']);
        }
     return view('user.payment',['cart'=>$cart,'product'=>$product]);
    }
    function store(Request $request){
        $name = $request->input('name');
        $address = $request->input('address');
        $phone = $request->input('phone');
        $note = $request->input('note');
        if($note==null){
            $note = '';
        }
        $id_user = Auth::user()->id;
        $cart = DB::table('cart')->where('id_user',$id_user)->get();
        foreach ($cart as $item){
             $product[] = DB::table('product')->where('id',$item->id_product)->get('id');

        }
        $cartItem[] = DB::table('cart')->where('id_user',$id_user)->get('quantity');
        $Converproduct= implode(',',$product);
        $Convercart = implode(',',$cartItem);
        echo $Convercart;
         DB::table('orders')->insert(['name_cus'=>$name,'address_cus'=>$address,'phone_cus'=>$phone
         ,'note_cus'=>$note,'id_product'=>$Converproduct,'quantity'=>$Convercart,'status'=>'check','payment'=>'after']);
        return redirect('home');
    }
}
