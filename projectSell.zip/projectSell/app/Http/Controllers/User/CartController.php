<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
class CartController extends Controller
{
    function index(){
        $id_user = Auth::user()->id;
        $cart = DB::table('cart')->where('id_user',$id_user)->get();

        foreach ($cart as $item){
            $product[] = DB::table('product')->where('id',$item->id_product)->get();
        }
         return view('user.cart',['product'=>$product,'cart'=>$cart]);

    }

    function store($id_product){
        $id_user = Auth::user()->id;
        $cart = DB::table('cart')->where('id_user',$id_user)->where('id_product',$id_product)->first();

        if($cart){
            DB::table('cart')->where('id',$cart->id)->update(['quantity'=>$cart->quantity+1]);
        }else{
            DB::table('cart')->insert(['id_user'=>$id_user,'id_product'=>$id_product,'quantity'=>1]);
        }
        return redirect('home');
    }
    function storeCart($id_product,Request $request){
        $qty = $request->input('qty-cart');
        $id_user = Auth::user()->id;
        $cart = DB::table('cart')->where('id_user',$id_user)->where('id_product',$id_product)->first();
        if($cart){
            DB::table('cart')->where('id',$cart->id)->update(['quantity'=>$cart->quantity+$qty]);
        }else{
            DB::table('cart')->insert(['id_user'=>$id_user,'id_product'=>$id_product,'quantity'=>$qty]);
        }
        return redirect('/cart');
    }
    function update($id,Request $request){
            $qty = $request->input('qty-cart');
            DB::table('cart')->where('id',$id)->update(['quantity'=>$qty]);
          return redirect()->route('user.cart',['message'=>'Cập nhật thành công']);
    }
    function destroy($id){
        DB::table('cart')->where('id',$id)->delete();
        return redirect('/cart');
    }
}
