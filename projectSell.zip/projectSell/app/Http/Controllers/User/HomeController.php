<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Session;
class HomeController extends Controller
{
    function index(){
        $phone = DB::table('product')->where('category','phone')->orderBy('id','DESC')->limit(4)->get();
        $hotphone = DB::table('product')->where('category','phone')->limit(3)->get();
        if(isset(Auth::user()->id)){
            $countCart = DB::table('cart')->where('id_user',Auth::user()->id)->count();
            Session::put('countCart', $countCart);
        }
        return view('user.home',['phone'=>$phone,'hotphone'=>$hotphone]);
    }
    function details($id){
        $getProduct = DB::table('product')->find($id);
        $detail = explode('//', $getProduct->detail);
        $sameproduct= DB::table('product')->where('category','phone')->limit(4)->get();
         return view('user.product.details',['product'=>$getProduct,'detail'=>$detail,'sameproduct'=>$sameproduct]);
     }

}
